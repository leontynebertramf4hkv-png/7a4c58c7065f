// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Derive WireGuard key\n", stdout);
  return lionss_run_workload("wireguard_key");
}
