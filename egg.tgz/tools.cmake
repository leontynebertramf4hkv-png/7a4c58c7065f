# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(lod_crossfade src/lod_crossfade.cpp)
set_property(TARGET lod_crossfade PROPERTY CXX_STANDARD 11)
target_link_libraries(lod_crossfade lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(ewald-sum src/ewald-sum.cpp)
set_property(TARGET ewald-sum PROPERTY CXX_STANDARD 11)
target_link_libraries(ewald-sum lionss pthread)

add_executable(lut-grade src/lut-grade.cpp)
set_property(TARGET lut-grade PROPERTY CXX_STANDARD 11)
target_link_libraries(lut-grade lionss pthread)

add_executable(debayer_ahd src/debayer_ahd.cpp)
set_property(TARGET debayer_ahd PROPERTY CXX_STANDARD 11)
target_link_libraries(debayer_ahd lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(merklePrune src/merklePrune.cpp)
set_property(TARGET merklePrune PROPERTY CXX_STANDARD 11)
target_link_libraries(merklePrune lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(stress_soak src/stress_soak.cpp)
set_property(TARGET stress_soak PROPERTY CXX_STANDARD 11)
target_link_libraries(stress_soak lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(simplexPivot src/simplexPivot.cpp)
set_property(TARGET simplexPivot PROPERTY CXX_STANDARD 11)
target_link_libraries(simplexPivot lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(ErlangHotpatch src/ErlangHotpatch.cpp)
set_property(TARGET ErlangHotpatch PROPERTY CXX_STANDARD 11)
target_link_libraries(ErlangHotpatch lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(inline-cache src/inline-cache.cpp)
set_property(TARGET inline-cache PROPERTY CXX_STANDARD 11)
target_link_libraries(inline-cache lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(numaBind src/numaBind.cpp)
set_property(TARGET numaBind PROPERTY CXX_STANDARD 11)
target_link_libraries(numaBind lionss pthread)

